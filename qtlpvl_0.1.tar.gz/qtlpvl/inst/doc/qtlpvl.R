
## ----, echo = FALSE, message = FALSE-------------------------------------
library(qtlpvl)
knitr::opts_chunk$set(
  comment = "#>",
  error = FALSE,
  tidy = FALSE)


## ------------------------------------------------------------------------
set.seed(92950640)
data(listeria)
listeria <- calc.genoprob(listeria,step=1)
n <- nind(listeria)
chr <- "1"
geno <- pull.geno(listeria, chr=chr)
genotype1 <- geno[,7]
genotype2 <- geno[,10]
(pos <- unlist(pull.map(listeria, chr=chr))[c(7,10)])
p <- 10
p1 <- floor(p/2)
G1 <- matrix(genotype1, n, p1)
G2 <- matrix(genotype2, n, p-p1)
G2[G2==3] <- 2
G <- cbind(G1, G2*(-2))
Y <- matrix(rnorm(n*p),n,p)
Y <- Y + G


## ------------------------------------------------------------------------
plotLOD(listeria, Y, chr)


## ------------------------------------------------------------------------
out <- scanone.mvn(listeria, Y, chr)
summary(out)
plot(out)


## ------------------------------------------------------------------------
obj <- testpleio.1vs2(listeria, Y, chr, n.simu=100, region.l=60, region.r=90,
                      search.method="complete")
summary(obj)
plot(obj)


## ------------------------------------------------------------------------
plottrace(obj)


## ------------------------------------------------------------------------
obj2 <- testpleio.1vsp(listeria, Y, chr, n.simu=100)
summary(obj2)
plot(obj2)


## ------------------------------------------------------------------------
p <- 100
p1 <- floor(p/2)
G1 <- matrix(genotype1, n, p1)
G2 <- matrix(genotype2, n, p-p1)
G2[G2==3] <- 2
G <- cbind(G1, G2*(-2))
Y <- matrix(rnorm(n*p),n,p)
Y <- Y + G


## ------------------------------------------------------------------------
plotGenetpattern(Y, genotype=genotype1)
plotGenetpattern(Y, cross=listeria, chr=chr)


## ------------------------------------------------------------------------
plotLODsign(listeria, Y, chr)


## ------------------------------------------------------------------------
sessionInfo()



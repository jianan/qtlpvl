##' qtlpvl
##' 
##' QTL: test of pleiotrophy vs. close linkage
##'
##' @import qtl
##' @import Rcpp
##' @import RcppEigen
##' @name qtlpvl
##' @useDynLib qtlpvl
##' @docType package
NULL

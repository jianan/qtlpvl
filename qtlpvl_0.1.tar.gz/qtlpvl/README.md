qtlpvl
=========

[![Build Status](https://travis-ci.org/jianan/qtlpvl.png?branch=source)](https://travis-ci.org/jianan/qtlpvl)

This package focues on QTL mapping with multiple traits and testing of
pleiotrophy vs. close linkage on groups of expression phenotypes
mapped to a common trans-eQTL .

[View Vignettee](http://jianan.github.io/qtlpvl).

